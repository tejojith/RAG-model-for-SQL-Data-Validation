# review-collect

### TODO:
- [x] Make the scraper
- [x] Flask app to get form data
- [x] Frontend form
- [x] Display data after form submission
- [x] Use huggingface API to use the summarizer
- [x] Design the website to make it look not ugly
- [x] About pages, Bug fixes etc. 