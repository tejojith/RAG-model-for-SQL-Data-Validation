PROJECT_PATH = "codebase"      # <-- Change this to your folder with text/code
DB_PATH = "chromadb_storage_new" 